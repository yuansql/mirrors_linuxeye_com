#ifndef __FTPWHO_READ_H__
#define __FTPWHO_READ_H__ 1

#ifdef PER_USER_LIMITS

unsigned int ftpwho_read_count(const char * const user);

#endif

#endif
