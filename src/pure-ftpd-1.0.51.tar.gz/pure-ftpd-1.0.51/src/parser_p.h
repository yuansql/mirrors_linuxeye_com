#ifndef __PARSER_P_H__
#define __PARSER_P_H__ 1

#define CONFIG_COMMENT '#'

#ifndef LINE_MAX
# define LINE_MAX 4096
#endif

#endif
