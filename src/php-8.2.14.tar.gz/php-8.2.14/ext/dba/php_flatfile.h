#ifndef PHP_FLATFILE_H
#define PHP_FLATFILE_H

#ifdef DBA_FLATFILE

#include "php_dba.h"

DBA_FUNCS(flatfile);

#endif

#endif
